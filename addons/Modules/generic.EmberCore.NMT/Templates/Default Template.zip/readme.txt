Default Ember Skin

Skin Home Menu based on Alaska Skin from ejp [http://networkedmediatank.com/showthread.php?tid=36569] 
More credits on the page