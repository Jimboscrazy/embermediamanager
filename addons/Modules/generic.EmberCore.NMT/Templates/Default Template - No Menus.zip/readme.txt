This is a BASIC skin build only to show some Module Capabilities
PLEASE NOTE, for this template you need to
Set TV Show Poster as -Poster- and 
All Season Poster as -Banner-

NOTICE:
Skin Home Menu based on Alaska Skin from ejp [http://networkedmediatank.com/showthread.php?tid=36569] 
(More credits on the page)

